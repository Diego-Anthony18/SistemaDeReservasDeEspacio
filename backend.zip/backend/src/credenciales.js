// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDlSXXS3y1N8tk2FWG2qaXo-3qHspcZAWE",
    authDomain: "reservas-de-espacios-6dc9f.firebaseapp.com",
    projectId: "reservas-de-espacios-6dc9f",
    storageBucket: "reservas-de-espacios-6dc9f.appspot.com",
    messagingSenderId: "150030187248",
    appId: "1:150030187248:web:7ac98f77fd3d4e1cfa6035"
};

// Initialize Firebase
const appFirebase = initializeApp(firebaseConfig);
export default appFirebase;