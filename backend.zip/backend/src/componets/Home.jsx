import { getAuth, signOut } from "firebase/auth";
import React from "react";
import appFirebase from "../credenciales";
const auth = getAuth(appFirebase)
const Home = ({ correoUsuario }) => {
    return (
        <div>
            <h2>este es el home usuario {correoUsuario} <button onClick={() => signOut(auth)}>cerrar sesion</button> </h2>

        </div>
    )
}
export default Home