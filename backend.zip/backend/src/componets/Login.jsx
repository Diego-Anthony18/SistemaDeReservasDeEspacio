import { createUserWithEmailAndPassword, getAuth, signInWithEmailAndPassword } from "firebase/auth";
import React, { useState } from "react";
import appFirebase from "../credenciales";
const auth = getAuth(appFirebase)


const Login = () => {
    const [registrando, setRegistrando] = useState(false)
    const functAutenticacion = async (e) => {
        e.preventDefault();
        const correo = e.target.email.value;
        const constraseña = e.target.password.value;


        if (registrando) {
            try {
                await createUserWithEmailAndPassword(auth, correo, constraseña)
            } catch (error) {
                alert("Asegurese que la contraseña tenga mas de 5 caracteres")
            }
        }
        else {
            try {
                await signInWithEmailAndPassword(auth, correo, constraseña)
            } catch (error) {
                alert("El correo o la contraseña son incorrecto")
            }


        }


    }

    return (
        <div>
            <form onSubmit={functAutenticacion}>
                <input type="text" placeholder="Ingrese el Email" id="email" />
                <input type="password" placeholder="Ingrese Contraseña" id="password" />
                <button>{registrando ? "Registrate" : "Inicia Sesion"}</button>

            </form>
            <h2>{registrando ? "Si ya tienes cuenta" : "No tienes cuenta"}<button onClick={() => setRegistrando(!registrando)}>{registrando ? "Inicia sesion" : "Registrate"}</button></h2>

        </div>
    )
}
export default Login