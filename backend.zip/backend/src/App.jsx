import { useState } from 'react'
//importar modulos de firebase//////////////////////////////
import { getAuth, onAuthStateChanged } from 'firebase/auth'
import appFirebase from './credenciales'
const auth = getAuth(appFirebase)

//importar componentes ////////////////////7


import './App.css'
import Home from './componets/Home'
import Login from './componets/Login'

function App() {
  const [usuario, setUsuario] = useState(null)

  onAuthStateChanged(auth, (usuarioFirebase) => {
    if (usuarioFirebase) {
      setUsuario(usuarioFirebase)
    }
    else {
      setUsuario(null)
    }
  })

  return (
    <div>
      {usuario ? <Home correoUsuario={usuario.email} /> : <Login />}

    </div>
  )
}

export default App
